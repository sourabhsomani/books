﻿using System.Web.Mvc;

namespace Mobile_Web.Extensions
{
    public class MobileEnabledViewEngine : WebFormViewEngine
    {
        public override ViewEngineResult FindView(ControllerContext controllerContext, string viewName, string masterName, bool useCache)
        {
            ViewEngineResult result = null;

            var browser = controllerContext.HttpContext.Request.Browser;

            if(browser.IsMobileDevice)
            {
                if (browser.MobileDeviceModel.Contains("iPhone"))
                    result = base.FindView(controllerContext, "iPhone/" + viewName, masterName, useCache);

                // Add any other specific devices you'd like to support here...

                if (result == null || result.View == null)
                    result = base.FindView(controllerContext, "Mobile/" + viewName, masterName, useCache);
            }

            return result ?? base.FindView(controllerContext, viewName, masterName, useCache);
        }
    }
}