using System;
using System.Collections.Generic;
using System.Linq;

namespace Mobile_Web.Models
{
    public class ProductDatabase
    {
        public IEnumerable<Product> GetFeaturedProducts()
        {
            return GetAllProducts().Where(p => p.IsFeatured = true);
        }

        public Product GetProductById(int productID)
        {
            return GetAllProducts().Where(p => p.Id == productID).SingleOrDefault();
        }

        public IEnumerable<Product> GetProductsByCategory(string id, int? page, int? size)
        {
            return GetAllProducts();
        }

        public IEnumerable<Product> GetAllProducts()
        {
            yield return new Product()
                             {
                                 Id = 1,
                                 DisplayName = "Xbox 360 Arcade",
                                 Description = "The Xbox 360 Arcade console is everything you need to hit the ground running. Plug in the console and connect the wireless controller and you're playing.",
                                 Price = 199.99,
                                 QuantityInStock = 84,
                                 ImageUrl = "~/Content/images/Xbox360.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 2,
                                 DisplayName = "Xbox 360 Wireless controller",
                                 Description = "High-performance wireless gaming now comes in black! Using optimized technology, the black Xbox 360 Wireless Controller lets you enjoy a 30-foot range and up to 40 hours of life on the two included AA batteries",
                                 Price = 39.99,
                                 QuantityInStock = 142,
                                 ImageUrl = "~/Content/images/Xbox360WirelessController.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 3,
                                 DisplayName = "Xbox 360 Wireless Racing Wheel",
                                 Description = "Racing has never felt so real! Hold on tight as you hug corner after corner, skid through the sand, or trade paint with rival cars fighting for position�the wireless wheel* simulates all the resistance and force, immersing you in a relentless and unparalleled racing experience.",
                                 Price = 79.99,
                                 QuantityInStock = 320,
                                 ImageUrl = "~/Content/images/Xbox360WheelController.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 4,
                                 DisplayName = "Xbox 360 Headset",
                                 Description = "The Xbox 360 Headset heightens the experience of the Xbox LIVE� online gaming community, allowing you to strategize with teammates, trash-talk opponents, or just chat with friends while playing your favorite games",
                                 Price = 19.99,
                                 QuantityInStock = 245,
                                 ImageUrl = "~/Content/images/Xbox360Headset.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 5,
                                 DisplayName = "Xbox 360 Memory Unit (512MB)",
                                 Description = "Take your games everywhere you go with eight times the space of the original Xbox 360 Memory Unit. With 512 MB of memory and a keychain carrying case",
                                 Price = 49.99,
                                 QuantityInStock = 123,
                                 ImageUrl = "~/Content/images/Xbox360MemoryUnit.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 6,
                                 DisplayName = "Xbox 360 Messenger Kit",
                                 Description = "Chatting with friends and family on Xbox LIVE� and Windows-based PCs is easy using the Xbox 360 Messenger Kit. ",
                                 Price = 29.99,
                                 QuantityInStock = 49,
                                 ImageUrl = "~/Content/images/xbox360MessengerKit.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 7,
                                 DisplayName = "Xbox 360 Halo 3 Special Edition Console",
                                 Description = "The Xbox 360 Halo� 3 Special Edition Console features an exclusive \"Spartan green and gold\" finish and comes bundled with a matching Xbox 360 Wireless Controller, 20GB Hard Drive, Headset, Play & Charge Kit, and exclusive Halo 3 Gamer Pics",
                                 Price = 259.99,
                                 QuantityInStock = 57,
                                 ImageUrl = "~/Content/images/xbox360Halo3EditionConsole.jpg"
                             };
            yield return new Product()
                             {
                                 Id = 8,
                                 DisplayName = "Xbox 360 Hard Drive (120 GB)",
                                 Description = "The Xbox 360 120GB Hard Drive is the best option for media enthusiasts who game on Xbox 360. It is the largest storage option for Xbox 360. Expand your Xbox 360 experience with downloadable content",
                                 Price = 169.99,
                                 QuantityInStock = 16,
                                 ImageUrl = "~/Content/images/xbox360HardDrive.jpg"
                             };
        }
    }
}