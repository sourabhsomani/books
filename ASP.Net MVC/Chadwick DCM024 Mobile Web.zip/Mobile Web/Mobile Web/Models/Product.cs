using System;

namespace Mobile_Web.Models
{
    [Serializable]
    public class Product
    {
        public int Id { get; set;}

        public string DisplayName { get; set; }

        public double Price { get; set; }

        public int QuantityInStock { get; set; }

        public string ImageUrl { get; set; }

        public string Description { get; set; }

        public bool IsFeatured { get; set; }

        public string ThumbnailUrl
        {
            // Just cheat and use the image url - we're not doing anything fancy here...
            get { return ImageUrl; }
            set { }
        }


        public Product()
        {
            IsFeatured = true;
        }
    }
}