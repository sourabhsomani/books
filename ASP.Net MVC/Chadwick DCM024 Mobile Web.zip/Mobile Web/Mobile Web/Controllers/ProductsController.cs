using System.Web.Mvc;
using Mobile_Web.Extensions;
using Mobile_Web.Models;

namespace Mobile_Web.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductDatabase _productData;

        public ProductsController()
        {
            _productData = new ProductDatabase();
        }

        public ActionResult Index()
        {
            ViewData["Title"] = "Products";

            var products = _productData.GetAllProducts();
            return View("List", products);
        }

        public ActionResult Featured()
        {
            ViewData["Title"] = "Featured Products";

            var featuredProducts = _productData.GetFeaturedProducts();
            return View("FeaturedProducts", featuredProducts);
        }

        [MobilePagingRestriction(MaxPageSize = 10)]
        public ActionResult Category(string id, int? page, int? pageSize)
        {
            ViewData["Title"] = "Products by Category";

            var productsByCategory = _productData.GetProductsByCategory(id, page, pageSize);
            return View("List", productsByCategory);
        }

        public ActionResult Details(int id)
        {
            var product = _productData.GetProductById(id);

            ViewData["Title"] = "Products details: " + product.DisplayName;

            return View(product);
        }

    }
}
