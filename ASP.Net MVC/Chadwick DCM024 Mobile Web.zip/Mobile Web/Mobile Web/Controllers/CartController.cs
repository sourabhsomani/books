﻿using System.Collections.Generic;
using System.Web.Mvc;
using Mobile_Web.Models;

namespace Mobile_Web.Controllers
{
    public class CartController : Controller
    {
        private readonly ProductDatabase _productData;

        protected IList<Product> Cart
        {
            get
            {
                var cart = Session["Cart"] as IList<Product>;
                
                if(cart == null)
                    Session["Cart"] = cart = new List<Product>();
                
                return cart;
            }
        }

        public CartController()
        {
            _productData = new ProductDatabase();
        }

        public ActionResult Index()
        {
            return View(Cart);
        }

        public ActionResult Add(int id)
        {
            var product = _productData.GetProductById(id);

            Cart.Add(product);

            ViewData["ProductAddedMessage"] = string.Format("Added {0} to cart.", product.DisplayName);

            return View("Index", Cart);
        }
    }
}
