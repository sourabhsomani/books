﻿using System.Web.Mvc;

namespace Mobile_Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Title"] = "Home";

            if (Request.Browser.MobileDeviceModel.Contains("iPhone"))
                return View();

            return RedirectToAction("Featured", "Products");
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
