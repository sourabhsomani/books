﻿namespace Microsoft.Samples.PlanMyNight.Data.Tests
{
    using System;

    internal sealed class Constants
    {
        public static readonly Guid TestUserId = new Guid("00000000-0000-0000-0000-000000000001");
        public static readonly string TestUserName = "Test User 1";
    }
}
