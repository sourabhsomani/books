﻿namespace Microsoft.Samples.PlanMyNight.Bing
{
    public struct BingCoordinate
    {
        public float Longitude;

        public float Latitude;
    }
}
