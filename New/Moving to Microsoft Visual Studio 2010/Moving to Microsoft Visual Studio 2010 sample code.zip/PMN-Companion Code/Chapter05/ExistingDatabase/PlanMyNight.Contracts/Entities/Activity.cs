﻿namespace Microsoft.Samples.PlanMyNight.Entities
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    [Serializable]
    public class Activity
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string BingId { get; set; }

        [DataMember]
        public int TypeId { get; set; }

        [DataMember]
        public string PhoneNumber { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string State { get; set; }

        [DataMember]
        public string Zip { get; set; }

        [DataMember]
        public string Street { get; set; }

        [DataMember]
        public string City { get; set; }

        [DataMember]
        public double[] Location { get; set; }

        [DataMember]
        public double Distance { get; set; }

        [DataMember]
        public int RatingCount { get; set; }

        [DataMember]
        public double Rating { get; set; }
    }
}
