﻿namespace Microsoft.Samples.PlanMyNight.Entities
{
    using System;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public class ActivityAddress
    {
        [DataMember]
        public string StreetAddress { get; set; }

        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string State { get; set; }

        [DataMember]
        public string Zip { get; set; }

        public override string ToString()
        {
            return string.Format(CultureInfo.CurrentUICulture, "{0}, {1}, {2} {3}", this.StreetAddress, this.City, this.State, this.Zip);
        }
    }
}
