﻿namespace Microsoft.Samples.PlanMyNight.Entities
{
    public partial class ItineraryComment
    {
        public string DisplayName { get; set; }
    }
}
