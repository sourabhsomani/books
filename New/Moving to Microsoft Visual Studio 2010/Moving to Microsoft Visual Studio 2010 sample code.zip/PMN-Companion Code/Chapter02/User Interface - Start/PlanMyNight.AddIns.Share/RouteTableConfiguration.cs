﻿namespace Microsoft.Samples.PlanMyNight.AddIns.Share
{
    using System.ComponentModel.Composition;
    using System.Web.Mvc;
    using System.Web.Routing;

    public class RouteTableConfiguration
    {
        public const string AreaName = "PlanMyNight.AddIns.Share";

        [Export(typeof(RouteCollection))]
        public RouteCollection RouteCollectionConfiguration
        {
            get
            {
                var routes = new RouteCollection();
                var areaContext = new AreaRegistrationContext(AreaName, routes);

                areaContext.MapRoute(
                    "ShareItinerary",
                    "Itineraries/Share/{action}",
                    new { controller = "Sharing" },
                    new[] { "Microsoft.Samples.PlanMyNight.AddIns.Share.Controllers" });

                return routes;
            }
        }
    }
}