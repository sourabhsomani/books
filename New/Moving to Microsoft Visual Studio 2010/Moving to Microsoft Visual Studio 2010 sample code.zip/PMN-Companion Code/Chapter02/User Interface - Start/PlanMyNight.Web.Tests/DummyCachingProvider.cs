﻿namespace Microsoft.Samples.PlanMyNight.Web.Helpers.Tests
{
    using System;
    using Microsoft.Samples.PlanMyNight.Data;

    public class DummyCachingProvider : ICachingProvider
    {
        public bool HasKey(string container, string key)
        {
            return false;
        }

        public object Get(string container, string key)
        {
            return null;
        }

        public void Add(string container, string key, object value, TimeSpan timeout)
        {
        }

        public void Remove(string container, string key)
        {
        }
    }
}
