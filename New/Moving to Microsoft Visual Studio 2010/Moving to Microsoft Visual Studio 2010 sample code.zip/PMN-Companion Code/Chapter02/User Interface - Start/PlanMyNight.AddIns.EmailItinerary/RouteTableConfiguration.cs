﻿namespace Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary
{
    using System.ComponentModel.Composition;
    using System.Web.Mvc;
    using System.Web.Routing;

    public class RouteTableConfiguration
    {
        public const string AreaName = "PlanMyNight.AddIns.EmailItinerary";

        [Export(typeof(RouteCollection))]
        public RouteCollection RouteCollectionConfiguration
        {
            get
            {
                var routes = new RouteCollection();
                var areaContext = new AreaRegistrationContext(AreaName, routes);

                areaContext.MapRoute(
                    "ItineraryEmail",
                    "Itineraries/Email/{action}",
                    new { controller = "EmailItinerary" },
                    new[] { "Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary.Controllers" });

                return routes;
            }
        }
    }
}