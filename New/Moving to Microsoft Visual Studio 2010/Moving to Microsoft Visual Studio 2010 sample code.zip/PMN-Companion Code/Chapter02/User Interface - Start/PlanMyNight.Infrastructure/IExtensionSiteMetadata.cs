﻿namespace Microsoft.Samples.PlanMyNight.Infrastructure
{
    using System;

    public interface IExtensionSiteMetadata
    {
        string TargetExtensionSite { get; }
    }
}
