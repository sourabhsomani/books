﻿namespace Microsoft.Samples.PlanMyNight.AddIns.PrintItinerary
{
    using System.ComponentModel.Composition;
    using System.Web.Mvc;
    using System.Web.Routing;

    public class RouteTableConfiguration
    {
        public const string AreaName = "PlanMyNight.AddIns.PrintItinerary";

        [Export(typeof(RouteCollection))]
        public RouteCollection RouteCollectionConfiguration
        {
            get
            {
                var routes = new RouteCollection();
                var areaContext = new AreaRegistrationContext(AreaName, routes);

                areaContext.MapRoute(
                    "PrintItinerary",
                    "Itineraries/Print/{id}",
                    new { controller = "PrintItinerary", action = "Print", id = string.Empty },
                    new { id = @"^\d*$" },
                    new[] { "Microsoft.Samples.PlanMyNight.AddIns.PrintItinerary.Controllers" });

                return routes;
            }
        }
    }
}