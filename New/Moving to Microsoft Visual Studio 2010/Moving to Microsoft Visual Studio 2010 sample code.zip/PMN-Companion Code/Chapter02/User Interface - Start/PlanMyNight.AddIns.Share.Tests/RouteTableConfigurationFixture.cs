﻿namespace Microsoft.Samples.PlanMyNight.AddIns.Share.Tests
{
    using System.Linq;
    using System.Web.Routing;
    using Microsoft.Samples.PlanMyNight.AddIns.Share.Controllers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MvcContrib.TestHelper;

    [TestClass]
    public class RouteTableConfigurationFixture
    {
        [TestMethod]
        public void TestRoutes()
        {
            RouteTable.Routes.Clear();
            RouteCollection routes = new RouteTableConfiguration().RouteCollectionConfiguration;
            routes.ToList().ForEach(RouteTable.Routes.Add);
            "~/Itineraries/Share/ShortUrl".ShouldMapTo<SharingController>(c => c.ShortUrl(null));
            "~/Itineraries/Share/ShortUrlToolbox".ShouldMapTo<SharingController>(c => c.ShortUrlToolbox());
        }
    }
}
