Welcome to the Mobile Device Browser File!
http://mdbf.codeplex.com
----------------------------------------------------------------------------------------------------

Included in this package:
   * mobile.browser               � Updated mobile browser definitions file with over 40 
                                    new capabilities and over 400 devices.
   * Capability Documentation.lnk � Shortcut to the capability documentation on CodePlex
   * EULA.rtf                     � End User License Agreement


Requirements:
   * See: http://mdbf.codeplex.com/Wiki/View.aspx?title=Requirements


====================================================================
Release Notes (2009-05-14):
====================================================================

   Issues resolved
   -----------------------------------------------------------------
      * [Data] HTC - Touch HD: Incorrect capabilities in Pocket IE4 
               and Opera 9.5  
        http://mdbf.codeplex.com/WorkItem/View.aspx?WorkItemId=2579
   
   New devices added
   -----------------------------------------------------------------
      * Alcatel OT-C652a
      * Alcatel OT-S621A
      * Alcatel OT-S521A
      * Casio c711
      * Casio C721
      * Casio gz1s
      * HTC Touch HD
      * HTC XV6175
      * HTC XV6800
      * Kyocera Lightpipe
      * Kyocera S2410
      * Kyocera S4000
      * LG KF390Q
      * LG LG3300
      * LG VX10000
      * Motorola E8
      * Nokia 3600slide
      * Nokia 6300
      * Nokia 7510
      * Nokia E63
      * PANTECH 315
      * SAGEM my700x
      * SAMSUNG M7600
      * SAMSUNG S5600
      * SAMSUNG S8300
      * SAMSUNG SCH-F519
      * SAMSUNG SCH-F609
      * SAMSUNG SCH-F639
      * SAMSUNG SGH-M130L
      * SAMSUNG SEC-SGHE496
      * SAMSUNG SEC-SGHI321N
      * SAMSUNG SEC-SGHE215L
      * SAMSUNG SEC-SGHM320L
      * SAMSUNG SGH-A736
      * SAMSUNG SGH-A767
      * SAMSUNG SGH-A777
      * SAMSUNG SGH-C166
      * SAMSUNG SGH-E251L
      * SAMSUNG SPHA580
      * SAMSUNG SPHA660
      * SAMSUNG SPHA680
      * SAMSUNG SPHA740
      * SAMSUNG SPHA860
      * SAMSUNG SPHM320
      * Sony Ericsson F305
      * Sony Ericsson K300a
      * Sony Ericsson T700
      * Sony Ericsson W600i
      * Sony Ericsson Z310a
      * Sprint Treo850e
      * Telstra F860
      * UTSTARCOM 7075
      * UTSTARCOM 7126M
      * UTSTARCOM 7176M
      * UTSTARCOM CDM8935
      * UTSTARCOM TXT8010
      * Verizon XV6900



====================================================================
Release Notes (2009-04-18):
====================================================================

   Issues resolved
   -----------------------------------------------------------------
      * Bug: Android phone not detected as mobile device 
        http://mdbf.codeplex.com/WorkItem/View.aspx?WorkItemId=2603

      * [Data] Apple - iPhone: canInitiateVoiceCall should be true
        http://mdbf.codeplex.com/WorkItem/View.aspx?WorkItemId=2403
   
   New devices added
   -----------------------------------------------------------------
      * ALCATEL 701a
      * ALCATEL C550
      * Alcatel C635
      * Alcatel S321a
      * Audiovox CDM 180
      * BenQ E55
      * BlackBerry 8220
      * BlackBerry 8350i
      * BlackBerry Storm 8230
      * BlackBerry Storm 8630
      * HTC Magic
      * HTC P3300
      * Huawei U1205
      * LG KF300
      * LG KF755
      * LG KM500
      * LG KM710
      * LG KP115
      * LG KP130
      * LG KP215
      * LG KP260
      * LG ME 970
      * LG ME550
      * LG MG220
      * LG VX9600
      * LG VX9700
      * Motorola EM25
      * Motorola EM28
      * Motorola U3
      * Motorola V3xx
      * Motorola V9
      * Motorola W388
      * Motorola W396
      * Motorola W6
      * Motorola W755
      * Motorola ZN200
      * Motorola ZN5
      * Nokia 1680c
      * Nokia 3120c
      * Nokia 5000
      * Nokia 5130
      * Nokia 5130c
      * Nokia 5220
      * Nokia 5630 XpressMusic
      * Nokia 6120
      * Nokia 6260 Slide
      * Nokia E66
      * Nokia N79
      * Sagem 301
      * Sagem HELLO KITTY
      * Sagem my-501H
      * Sagem X6
      * Sagem X8
      * Samsung i908
      * Samsung J700i
      * Samsung S7350H
      * Samsung S8300H
      * Samsung SCH-A890
      * Samsung SCH-U810
      * Samsung SGH-376 ELF
      * Samsung SGH-B110
      * Samsung SGH-B2100V
      * Samsung SGH-C275L
      * Samsung SGH-C426
      * Samsung SGH-C516 MBENZ
      * Samsung SGH-F480L
      * Samsung SGH-M200
      * Samsung SGH-M310
      * Samsung SGH-X656 Klaus
      * Samsung SGH-X686
      * Samsung SGH-X836
      * Samsung Twinke B110L
      * Sony Ericsson C510
      * Sony Ericsson C901
      * Sony Ericsson C903
      * Sony Ericsson C905a
      * Sony Ericsson K330a
      * Sony Ericsson R300a
      * Sony Ericsson T303a
      * Sony Ericsson W200
      * Sony Ericsson W302
      * Sony Ericsson W595a
      * Sony Ericsson W610
      * Sony Ericsson W710
      * Sony Ericsson W760a
      * Sony Ericsson W910
      * Sony Ericsson W995
      * Sony Ericsson Z520
      * Sony Ericsson Z550
      * SonyEricsson W580 Imode
      * SonyEricsson W705
      * ZTE F260
      * ZTE F868
      * ZTE I766