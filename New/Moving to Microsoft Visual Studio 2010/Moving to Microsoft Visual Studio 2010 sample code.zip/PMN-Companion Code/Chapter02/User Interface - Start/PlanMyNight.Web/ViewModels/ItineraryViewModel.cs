﻿namespace Microsoft.Samples.PlanMyNight.Web.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Web.Routing;
    using Microsoft.Samples.PlanMyNight.Infrastructure;

    public class ItineraryViewModel
    {
        public long Id { get; set; }

        public Guid UserId { get; set; }

        public string Name { get; set; }

        public DateTime Created { get; set; }

        public string Description { get; set; }

        public bool IsPublic { get; set; }

        public decimal Rating { get; set; }

        public int EstimatedMinutes { get; set; }

        public string AddActivitiesLink { get; set; }

        public string DetailsLink { get; set; }

        public int ActivitiesCount { get; set; }

        public IEnumerable<ActivityViewModel> Activities { get; set; }
    }
}
