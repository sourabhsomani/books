﻿namespace Microsoft.Samples.PlanMyNight.Web.ViewModels
{
    using System.Collections;
    using Microsoft.Samples.PlanMyNight.Entities;

    public class SearchViewModel
    {
        public SearchFields SearchFields { get; set; }

        public BaseSearchQuery Criteria { get; set; }

        public IEnumerable Items { get; set; }

        public bool AdvancedMode { get; set; }

        public int CurrentPage { get; set; }

        public int TotalPages { get; set; }

        public string NextPageLink { get; set; }

        public string PreviousPageLink { get; set; }

        public Activity SearchActivity { get; set; }

        public string CriteriaDescription { get; set; }

        public string KeywordsMetatag { get; set; }
    }
}
