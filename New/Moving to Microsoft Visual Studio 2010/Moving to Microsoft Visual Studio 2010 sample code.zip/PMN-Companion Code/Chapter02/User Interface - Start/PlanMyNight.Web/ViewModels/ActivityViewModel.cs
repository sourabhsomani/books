﻿namespace Microsoft.Samples.PlanMyNight.Web.ViewModels
{
    using Microsoft.Samples.PlanMyNight.Entities;

    public class ActivityViewModel
    {
        public Activity Entity { get; set; }

        public int EstimatedMinutes { get; set; }

        public string DetailsLink { get; set; }

        public string AddToItineraryLink { get; set; }

        public string RemoveFromItineraryLink { get; set; }

        public string ActivityItinerariesLink { get; set; }

        public string MoveUpInItineraryLink { get; set; }

        public string MoveDownInItineraryLink { get; set; }

        public string SetEstimatedTimeLink { get; set; }
    }
}
