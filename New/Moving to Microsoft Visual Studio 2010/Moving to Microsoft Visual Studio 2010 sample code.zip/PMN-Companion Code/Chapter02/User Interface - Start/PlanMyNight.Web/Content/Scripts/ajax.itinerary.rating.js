﻿// Rating functions
function ajaxRating() {
    $(".ratingEditable .static").hide();
    $(".ratingEditable .ajax").show();

    var ratingE = $(".ratingEditable .ajax:visible");
    ratingE.each(function (ix, item) {
        $create(AjaxControlToolkit.RatingBehavior, { "CallbackID": ratingControlCallback, "EmptyStarCssClass": "emptyRatingStar", "FilledStarCssClass": "filledRatingStar", "StarCssClass": "ratingStar", "WaitingStarCssClass": "savedRatingStar", "Rating": 0, "id": "RatingBehavior_" + item.id }, null, null, item);
    });
    rating = false;
}

function ratingControlCallback(value) {
    form = $('form.rating:visible');
    var uri = form[0].action;
    rating = true;
    postData = form.serialize() + "&Rating=" + parseInt(value);
    updateModel(
    uri,
    postData,
    function () { 
        $(".ratingEditable .ajax").addClass("loading").css("height", "20px").css("width", "80px");
        return true;
    },
    function (data) {       
        $("form.rating").empty().append('<span class="rating ' + data.UpdatedRatingCss + '"></span>');
        $("span.rating").attr("class", "rating " + data.UpdatedRatingCss);
    });
}

/* Needed for the rating control to work client side */
function WebForm_DoCallback(callback, args) {
    callback(args);
}

// ajax rating
ajaxRating();