﻿namespace WindowsLiveId
{
    using System.Web;

    public static class WindowsLiveHelper
    {
        private static readonly WindowsLiveLogin wll = new WindowsLiveLogin(true);

        public static WindowsLiveLogin.User ProcessLoginResponse()
        {
            return wll.ProcessLogin(HttpContext.Current.Request.Form);
        }

        public static string RetrieveLoginUrl()
        {
            return wll.GetLoginUrl();
        }

        public static string RetrieveLoginUrl(string returnUrl)
        {
            return wll.GetLoginUrl(returnUrl);
        }

        public static string RetrieveMobileLoginUrl()
        {
            return wll.GetMobileLoginUrl();
        }

        public static string RetrieveMobileLoginUrl(string returnUrl)
        {
            return wll.GetMobileLoginUrl(returnUrl);
        }

        public static string RetrieveLogoutUrl()
        {
            return wll.GetLogoutUrl();
        }
    }
}
