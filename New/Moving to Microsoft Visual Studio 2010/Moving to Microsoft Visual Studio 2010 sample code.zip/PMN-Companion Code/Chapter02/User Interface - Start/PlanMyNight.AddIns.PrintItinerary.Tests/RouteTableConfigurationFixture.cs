﻿namespace Microsoft.Samples.PlanMyNight.AddIns.PrintItinerary.Tests
{
    using System.ComponentModel.Composition.Hosting;
    using System.Linq;
    using System.Web.Routing;
    using Microsoft.Samples.PlanMyNight.AddIns.PrintItinerary.Controllers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MvcContrib.TestHelper;

    [TestClass]
    public class RouteTableConfigurationFixture
    {
        [TestMethod]
        public void ShouldHandleEmailSentUrl()
        {
            RouteTable.Routes.Clear();
            RouteCollection routes = new RouteTableConfiguration().RouteCollectionConfiguration;
            routes.ToList().ForEach(RouteTable.Routes.Add);

            var route = "~/Itineraries/Print/15".Route();
            route.ShouldMapTo<PrintItineraryController>();
            Assert.AreEqual("Print", route.Values.GetValue("action").ToString());
            Assert.AreEqual("15", route.Values.GetValue("id").ToString());
        }
    }
}
