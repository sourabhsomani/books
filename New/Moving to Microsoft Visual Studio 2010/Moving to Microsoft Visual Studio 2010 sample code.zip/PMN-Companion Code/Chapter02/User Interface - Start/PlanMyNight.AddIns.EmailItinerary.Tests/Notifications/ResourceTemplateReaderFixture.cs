﻿namespace Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary.Tests.Notifications
{
    using Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary.Notifications;
    using Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary.Tests.Properties;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ResourceTemplateReaderFixture
    {
        [TestMethod]
        public void RetrieveTemplateReadsFromResources()
        {
            var reader = new ResourceTemplateReader(Resources.ResourceManager);
            var template = reader.RetrieveTemplate("TestTemplate");
            Assert.AreEqual("#test-template#", template);
        }
    }
}
