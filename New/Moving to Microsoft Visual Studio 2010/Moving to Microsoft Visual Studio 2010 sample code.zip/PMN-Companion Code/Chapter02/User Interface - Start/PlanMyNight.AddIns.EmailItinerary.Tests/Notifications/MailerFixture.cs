﻿namespace Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary.Tests.Notifications
{
    using System.Net.Mail;
    using Microsoft.Samples.PlanMyNight.AddIns.EmailItinerary.Notifications;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class MailerFixture
    {
        [TestMethod]
        public void MailUsesAppConfig()
        {
            var mail = new MailMessage(new MailAddress("john.doe@microsoft.com", "John Doe"), new MailAddress("jane.doe@microsoft.com", "Jane Doe"));
            mail.Body = "Test Message";
            var mailer = new Mailer();
            mailer.SendMail(mail);
        }
    }
}
