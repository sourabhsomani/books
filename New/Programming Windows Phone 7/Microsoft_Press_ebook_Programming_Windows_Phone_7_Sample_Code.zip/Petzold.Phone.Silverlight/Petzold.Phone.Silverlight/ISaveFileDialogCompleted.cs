﻿namespace Petzold.Phone.Silverlight
{
    public interface ISaveFileDialogCompleted
    {
        void SaveFileDialogCompleted(bool okPressed, string filename);
    }
}
