﻿using System.Windows.Controls;

namespace Petzold.Phone.Silverlight
{
    public class AltSlider : Slider
    {
        public AltSlider()
        {
            this.DefaultStyleKey = typeof(AltSlider);
        }
    }
}
