﻿using System;

namespace MobileEnabledWebFormsApp.Mobile
{
    public partial class MobileMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
